import alt from '../alt';
import {assign} from 'underscore';

class ShowModalAction {
	constructor() {

	}
	
	showClickData(){
		// alert( $('.clickBtn').val());
	}

}

export default alt.createActions(ShowModalAction);